// Fill out your copyright notice in the Description page of Project Settings.


#include "AmaruPlayerController.h"

#include "EnhancedInputSubsystems.h"

void AAmaruPlayerController::CreateHUDInka()
{
	if (HUDInka) return;
    if (IsLocalPlayerController())
    {
        if (HUDInkaClass)
        {
            HUDInka = CreateWidget(this, HUDInkaClass);
            if (HUDInka)
            {
                HUDInka->AddToViewport();
            }
        }
    }
}

void AAmaruPlayerController::BeginPlay()
{
    Super::BeginPlay();

    if (!IsLocalPlayerController()) return;

    if (ULocalPlayer* LP = GetLocalPlayer())
    {
        if (auto* Subsystem = ULocalPlayer::GetSubsystem<UEnhancedInputLocalPlayerSubsystem>(LP))
        {
            Subsystem->ClearAllMappings();
            Subsystem->AddMappingContext(DefaultMappingContext, 0);
        }
    }

    CreateHUDInka();
}

void AAmaruPlayerController::OnPossess(APawn* InPawn)
{
	Super::OnPossess(InPawn);

    CreateHUDInka();

    /*if (HUDInka) {
        Cast<AAmaruShooterCharacter>(InPawn)->
    }*/
}
